Monoalpha can be used to generate generate code
alphabets, as well as encrypting, and decrypting
text. It supports caesar shift, ROT13, affine, atbash,
and keyword ciphers. It can also encrypt and decrypt
based on your own code alphabets.

